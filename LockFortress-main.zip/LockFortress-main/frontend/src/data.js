const selectarr = {
    dob: [
        "Born",
        "Borne",
        "Hatched",
        "Emerged",
        "Arrived",
        "Saw_the_light",
        "First_cried_on",
        "Began_life_on",
        "Materialized",
        "Manifested",
        "Appeared",
        "Debuted",
    ]
    ,

    favfood: [
        "Enjoys",
        "Loves",
        "Adores",
        "Favors",
        "Craves",
        "Cherishes",
        "Appreciates",
        "Devours",
        "Relishes",
        "Savors",
        "Treasures",
        "Esteems",
        "Indulges_in",
        "Nourishes",
        "Delights_in",
        "Covets",
        "Yearns_for",
        "Longs_for",
        "Desires",
        "Hungers_for",
    ],

    hobby: [
        "Enjoys",
        "Loves",
        "Adores",
        "Relishes",
        "Cherishes",
        "Appreciates",
        "Delights_in",
        "Finds_pleasure_in",
        "Takes_pleasure_in",
        "Savors",
        "Treasures",
        "Esteems",
        "Indulges_in",
        "Nourishes",
        "Is_passionate_about",
        "Is_enthusiastic_about",
    ],

    // quality: [
        
    // ]
}


export default selectarr